package competition.icegic.peterlawford.simulator;

public class Visualizer {
	public static final byte CLEAR = 0;

//	public static final byte MARIO = 1;
	public static final byte MARIO = -18;

	public static final byte WALL_CHECK = 3;
	public static final byte COIN = 34;
	public static final byte SHELL = 13;
	public static final byte FIREBALL = 25;

	public static final byte ENEMY_GOOMBA = 2;
	public static final byte ENEMY_FLYING_GOOMBA = 3;
	public static final byte ENEMY_RED_KOOPA = 4;
	public static final byte ENEMY_FLYING_RED_KOOPA = 5;
	public static final byte ENEMY_GREEN_KOOPA = 6;
	public static final byte ENEMY_FLYING_GREEN_KOOPA = 7;
	public static final byte ENEMY_BULLET = 8;
	public static final byte ENEMY_SPINY = 9;
	public static final byte ENEMY_FLYING_SPINY = 10;
	public static final byte ENEMY_PIRANHA_PLANT = 12;
}
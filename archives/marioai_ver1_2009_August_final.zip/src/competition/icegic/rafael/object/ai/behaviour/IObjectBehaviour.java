package competition.icegic.rafael.object.ai.behaviour;

public interface IObjectBehaviour
{
	public void behave(boolean Action[]);
}

package competition.icegic.rafael.object.area;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		float[] xx = new float[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
		float[] zz = null;

		for(int i=0; i < xx.length; i=i+3)
		{
//			zz = Arrays.copyOfRange(xx, i, i+3);
		}



		System.out.println("ok");
	}

}

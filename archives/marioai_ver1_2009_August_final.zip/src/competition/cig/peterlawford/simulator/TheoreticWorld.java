package competition.cig.peterlawford.simulator;

public class TheoreticWorld {

}

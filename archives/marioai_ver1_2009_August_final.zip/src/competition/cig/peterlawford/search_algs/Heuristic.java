package competition.cig.peterlawford.search_algs;

public abstract class Heuristic {

}

package competition.cig.peterlawford.search_algs;

public class PathInfo {

}

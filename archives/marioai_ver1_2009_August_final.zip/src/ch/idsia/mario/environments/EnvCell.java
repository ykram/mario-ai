package ch.idsia.mario.environments;

/**
 * Created by IntelliJ IDEA.
 * User: Sergey Karakovskiy
 * Date: Mar 28, 2009
 * Time: 11:43:58 PM
 * Package: .Environments
 */

public class EnvCell
{
    public int LevelFragment;
    public int Enemy;

}
